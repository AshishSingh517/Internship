package Exercise1;

import Exercise1.Car;

public class Main {
    public static void main(String[] args) {

    }
        Car bmw=new Car("bmw","luxury","Three Cylinder","Inline_six",350,"Three","Kevlar clutch");

    }

