package Exercise1;

public class Clutch  {
    private String clutchtype;

    public Clutch(String ct) {
        this.clutchtype = ct;
    }

    public void engageclutch() {

    }

    public void disengagage() {
    }

}