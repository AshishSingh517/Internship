package Exercise1;

public class Engine {

    private String manufacturer;
    private int horse_power;
    private String number_of_strokes;

    public Engine(String m, int hp, String nos) {
        this.manufacturer = m;
        this.horse_power = hp;
        this.number_of_strokes = nos;

    }

public void openvalve(){

}
public void closevalve(){
}




}