package Exercise1;

public class Car  {
   private String carmodel;
   private String cartype;


   private String color;
   Engine myEngine;
   Clutch myClutch;

   public static void main(String[] args) {

   }

   public Car(String cm, String ct, String c, String enginetype, int hp, String nos, String ctype) {
      myEngine = new Engine(enginetype, hp, nos);
      myClutch = new Clutch(ctype);
      this.carmodel = cm;
      this.cartype = ct;
      this.color=c;
      System.out.println();

   }
}
