package Exercise2;

public class Camera {
     private String front_camerasize;
     private String back_camerasize;
     public Camera(String fc,String bc){
       this.front_camerasize=fc;
       this.back_camerasize=bc;
     }
   public void startcamera(){

     }
     public void stopcamera(){

     }
}
