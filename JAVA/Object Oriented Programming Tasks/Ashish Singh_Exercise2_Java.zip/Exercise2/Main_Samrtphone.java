package Exercise2;

public class Main_Samrtphone {
    public static void main(String[] args) {
        phone oneplus=new phone("Android","onepus nord","oxygenOS","Qualcomm","twelve two MP","eight MP",6.72f,"8:4","Blue") ;
    }
}
