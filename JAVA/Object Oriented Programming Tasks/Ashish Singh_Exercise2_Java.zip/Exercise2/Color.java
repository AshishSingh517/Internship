package Exercise2;

public class Color {
    private String color;
    public void Color(String co){
        this.color=co;
    }
}
