package Exercise2;

public class phone {
    private String phonename;
    private String phonetype;
    private String operatingsystem;
    private String GPU;
    public phone(String pt,String pn,String os,String gpu,String fc,String bc,float s,String ar,String co){
        this.phonetype=pt;
        this.operatingsystem=os;
        this.GPU=gpu;
        this.phonename=pn;
    }
    }

