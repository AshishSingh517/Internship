package Exercise2;

public class Display {
    private float size;
    private int Aspectratio;
    public void Display(float s,int ar){
        this.size=s;
        this.Aspectratio=ar;
    }
    public void displayon(){

    }
    public void diaplayoff(){

    }

}
