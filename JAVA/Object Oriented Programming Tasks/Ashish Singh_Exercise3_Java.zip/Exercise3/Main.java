package Exercise3;


public class Main {
    public static void main(String[] args) {
        //CIRCLE
        Shape circle = new Circle(10.0);
        System.out.println("Circle Prperties:");
        System.out.println(circle.computeArea());
        System.out.println(circle.computePerimeter());
        System.out.println("\n");

        //RECTANGLE
        {

            Shape rectangle = new Rectangle(20, 55);
            System.out.println("Rectangle properties");
            System.out.println(rectangle.computeArea());
            System.out.println(rectangle.computePerimeter());
            System.out.println("\n");
        }

        //TRIANGLE
        {

            Shape triangle = new Triangle(10, 12, 15, 16);
            System.out.println("Triangle properties");
            System.out.println(triangle.computeArea());
            System.out.println(triangle.computePerimeter());
            System.out.println("\n");
        }

        // SQUARE
        {
            Shape square = new Square(10);
            System.out.println("Square Prperties:");
            System.out.println(square.computeArea());
            System.out.println(square.computePerimeter());
            System.out.println("\n");

        }

        //TRAPEZIUM
        {
            Shape trapezium = new Trapezium(10, 12, 15, 16, 10);
            System.out.println("Trapezium properties");
            System.out.println(trapezium.computeArea());
            System.out.println(trapezium.computePerimeter());
            System.out.println("\n");
        }

//PARALLELOGRAM
        {

            Shape parallelogram = new Parallelogram(15, 20);
            System.out.println("Parallelogram properties");
            System.out.println(parallelogram.computeArea());
            System.out.println(parallelogram.computePerimeter());

        }
    }
}