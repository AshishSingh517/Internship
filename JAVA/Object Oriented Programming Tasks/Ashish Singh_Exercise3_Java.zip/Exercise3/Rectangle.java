package Exercise3;

import java.lang.Math;

public class Rectangle extends Shape{
    private double Length;
    private  double Breadth;
    public Rectangle(double Length,double Breadth)
    {
        this.Length = Length;
this.Breadth=Breadth;
    }

    @Override
    public double computeArea() {
        double Area = Length*Breadth;
        return  Area;
    }

    @Override
    public double computePerimeter() {
        double perimeter=2*(Length+Breadth);
        return perimeter;
    }

    @Override
    public void drawShape() {

    }

    @Override
    public void colorShape() {

    }

}


