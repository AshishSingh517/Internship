package Exercise3;

public abstract class Shape {
    public abstract double computeArea();

    public abstract double computePerimeter();

    public abstract void drawShape();

    public abstract void colorShape();

}
