package Exercise3;

public class Triangle extends Shape {
    private double height;
    private double a;
    private double b;
    private double c;
    private double Breadth;

    public Triangle(double height, double a, double b, double c) {
        this.height = height;
        this.a = a;
        this.b = b;
        this.c = c;
    }

    @Override
    public double computeArea() {
        double area = (height * b) / 2;
        return area;
    }

    @Override
    public double computePerimeter() {
        double perimeter = a + b + c;
        return perimeter;
    }

    @Override
    public void drawShape() {

    }

    @Override
    public void colorShape(){

    }
}

