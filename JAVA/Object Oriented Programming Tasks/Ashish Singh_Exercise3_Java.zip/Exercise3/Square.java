package Exercise3;

import java.lang.Math;

public class Square extends Shape{
    private double side;
    public Square(double side)
    {
        this.side =side;

    }

    @Override
    public double computeArea() {
        double area = Math.pow(this.side,2);
        return area;
    }

    @Override
    public double computePerimeter() {
        double perimeter=4*side;
        return perimeter;
    }

    @Override
    public void drawShape() {

    }

    @Override
    public void colorShape() {

    }

}

