package Exercise3;
import java.lang.Math;

public class Parallelogram extends Shape{
    private double a;
    private  double b;
    public Parallelogram(double a,double b)
    {
        this.a=a;
        this.b=b;
    }

    @Override
    public double computeArea() {
        double Area = a*b;
        return  Area;
    }

    @Override
    public double computePerimeter() {
        double perimeter=2*(a+b);
        return perimeter;
    }

    @Override
    public void drawShape() {

    }

    @Override
    public void colorShape() {

    }

}



