package Exercise3;


public class Trapezium extends Shape {
    private double height;
    private double a;
    private double b;
    private double c;

    private double d;

    ;


    public Trapezium(double height, double a, double b, double c,double d) {
        this.height = height;
        this.a = a;
        this.b = b;
        this.c = c;
        this.d=  d;
    }

    @Override
    public double computeArea() {
        double area =(height*(a*b))/2;
        return area;
    }

    @Override
    public double computePerimeter() {
        double perimeter = (a + b + c+d);
        return perimeter;
    }

    @Override
    public void drawShape() {

    }

    @Override
    public void colorShape(){

    }
}


