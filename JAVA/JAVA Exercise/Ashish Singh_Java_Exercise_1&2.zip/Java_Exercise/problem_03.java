package Java_Exercise;

public class problem_03 {
    public static void main(String[] args) {
        float a = 10;
        double b = 15;
        byte c = 20;
        short d = 25;
        long e = 30;

        /* Reducing */
        short result = (short) e;
        short result_2 = (short) (c - e);
        short result_3 = (short) (e - a);
        long result_4=(long)(a);
        float result_5=(float)(e);
        float result_6=(float)(c);
        double result_7=(double)(c);

        /* Expanding */
        float result_8=c;
        short result_9=c;
        float result_10=d;
        long result_11=d;
        double result_12=a;
        double result_13=e;

        System.out.println(result);
        System.out.println(result_2);
        System.out.println(result_3);
        System.out.println(result_4);
        System.out.println(result_5);
        System.out.println(result_6);
        System.out.println(result_7);

        System.out.println(result_8);
        System.out.println(result_9);
        System.out.println(result_10);
        System.out.println(result_11);
        System.out.println(result_12);
        System.out.println(result_13);
            }
}
