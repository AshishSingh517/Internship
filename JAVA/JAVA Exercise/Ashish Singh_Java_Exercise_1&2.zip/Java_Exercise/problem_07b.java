package Java_Exercise;
import java.util.Scanner;
public class problem_07b {
    public static void main(String[] args) {

        int i=0, j;
        //Getting the size of the square side from user
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter the number of rows for star: ");
        int rows = sc.nextInt();

        while (i < rows )
        {
            j = 0 ;
            while ( j < rows )
            {
                if (i == 0 || i ==rows - 1 || j == 0 || j == rows - 1) {
                    System.out.print("*"+ " ");
                }
                else {
                    System.out.print(" "+ " ");
                }
                j++;
            }
            //To move cursor to new line for next row
            System.out.println();
            i++;
        }
    }
}