package Java_Exercise;

public class problem_02 {
    public static void main(String[] args) {
        float a=10;
        float b=12;
        float c=15;
        float d=20;
        float e=25;

       // 2a. Print result of ++a
        System.out.println(++a);

       // 2b. Print result of a++
        System.out.println(a++);

        // 2c. print result of (a++ + b++ ) / c++
        System.out.println((a++ + b++)/c++ );

       // 2d. print result of a/(b*(c + ++d))
        System.out.println(a/(b*(c + ++d)));

       // 2e. Print result of a^b++ + b ^ ++c + c ^ --d + d ^ e--
        System.out.println(Math.pow(a,b++)+Math.pow(b,++c)+Math.pow(c,--d)+Math.pow(d,e--));
    }
}
