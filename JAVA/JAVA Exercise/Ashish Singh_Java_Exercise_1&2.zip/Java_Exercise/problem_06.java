package Java_Exercise;

import java.util.Scanner;

public class problem_06 {
    public static void main(String[] args) {
        System.out.println("Enter a factorial number:");
        Scanner sc=new Scanner(System.in);
        int n=sc.nextInt();

        int fact = 1;
        for(int i = 1; i <= n; i++)
        {
            fact = fact * i;
        }
        System.out.println("Factorial of "+n+" is: "+fact);
    }

}
