package Java_Exercise;

import java.util.Scanner;

public class problem_05d {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        int i = 0;
        while (i <= 0) {
            System.out.println("Choose the trignometry function: type the keyword for cos-c, sin-s, tan-t, cosec-C, sec-S, cot-d: ");
            char operator = sc.next().charAt(0);

            System.out.println("Enter the degree:");
            double degrees = sc.nextDouble();

            // convert degrees to radians
            double radians = Math.toRadians(degrees);

            switch (operator) {
                case 'c':
                    double cosValue = Math.cos(radians);
                    System.out.println("cos(" + degrees + ") = " + cosValue);
                    break;

                case 's':
                    double SinValue = Math.sin(radians);
                    System.out.println("sin(" + degrees + ") = " + SinValue);
                    break;

                case 't':
                    double tanValue = Math.tan(radians);
                    System.out.println("tan(" + degrees + ") = " + tanValue);
                    break;

                case 'C':
                    double cosecValue = 1 / Math.sin(radians);
                    System.out.println("cosec(" + degrees + ") = " + cosecValue);
                    break;

                case 'S':
                    double secValue = 1 / Math.cos(radians);
                    System.out.println("sec(" + degrees + ") = " + secValue);
                    break;

                case 'd':
                    double cotValue = 1 / Math.tan(radians);
                    System.out.println("cot(" + degrees + ") = " + cotValue);

                    System.out.println("Press 0 to continue and 1 to exit");
                    int c = sc.nextInt();
                    if (c == 0) {
                        i = 0;
                    } else if (c == 1) {
                        i += c;
                    } else {
                        System.out.println("invalid choice");

                    }
            }
        }
    }
}
