package Java_Exercise;
import java.util.Scanner;

public class problem_05a {
    public static void main(String[] args) {
        double a, b,c;
        char st;

        Scanner sc = new Scanner(System.in);
        int i = 0;
        double result;
        while (i <= 0) {
            System.out.println("Enter the value of a");
            a = sc.nextDouble();

            System.out.println("Enter the value of b:");
            b = sc.nextDouble();

            result = Math.pow(a, b);
            System.out.println("Result is: " + result);

            System.out.println("Press 0 to continue and 1 to exit");
            c = sc.nextInt();
            if (c == 0) {
                i = 0;
            } else if(c==1){
                i+=c;
            } else{
                System.out.println("invalid choice");
            }
        }

    }


}