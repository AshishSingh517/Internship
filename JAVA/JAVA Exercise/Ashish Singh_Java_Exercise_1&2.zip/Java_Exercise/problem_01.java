package Java_Exercise;

public class problem_01 {
    public static void main(String[] args) {
        int a=10;
        int b=20;
        int c=24;
        int d=13;

        //1a. Print result of a-b / c
        System.out.println(a-b/c);

        //1b. Print result of (a - b) / c
        System.out.println((a-b)/c);

        //1c. print result of a/b*c+d
        System.out.println(a/b*c+d);

        //1d. print result of a/(b*(c+d))
        System.out.println(a/(b*(c+d)));

    }
}
