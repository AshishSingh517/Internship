package Java_Exercise;
import java.util.Scanner;
public class problem_07a {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("Number of star to be print:");
        int n= sc.nextInt();
        for (int i=0;i<=n;i++){
        System.out.print("* ");
        }
    }
}
