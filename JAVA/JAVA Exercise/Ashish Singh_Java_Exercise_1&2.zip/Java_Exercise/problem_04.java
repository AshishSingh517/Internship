package Java_Exercise;

import java.util.Scanner;

public class problem_04 {
    public static void main(String[] args) {
        float num1,num2,result;
        System.out.println("Choose the operation for \nAddition-a\nSubtraction-b\n Multiplication-m\n Division -d");
        Scanner cal=new Scanner(System.in);
        char calculator =cal.next().charAt(0);

        System.out.println("Enter value of a:");
     num1=cal.nextFloat();

        System.out.println("Enter the value of b:");
num2= cal.nextFloat();
switch (calculator) {
    case 'a':
        result = num1 + num2;
        System.out.println(result);
     break;
    case 's':
        result = num1 - num2;
        System.out.println(result);
        break;
    case 'm':
        result = num1 * num2;
        System.out.println(result);
        break;
    case 'd':
        result = num1 / num2;
        System.out.println(result);
        break;
    default:
        System.out.println("You have type a wrong keyword");
}
}
}