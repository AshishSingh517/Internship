package Java_Exercise;

import java.util.Scanner;

public class problem_05b {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        double a;
        double re;
        int i = 0;
        while (i <= 0) {
            System.out.println("Enter the value of exponential:");
            a = sc.nextInt();
            re = Math.exp(a);
            System.out.println("The result is " + re);
            System.out.println("Press 0 to continue and 1 to exit");
            int c = sc.nextInt();
            if (c == 0) {
                i = 0;
            } else if (c == 1) {
                i += c;
            } else {
                System.out.println("invalid choice");
            }
        }
    }
}
