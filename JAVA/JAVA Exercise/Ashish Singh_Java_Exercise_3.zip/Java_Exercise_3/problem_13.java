package Java_Exercise_3;

import java.util.Random;

public class problem_13 {
    public static void main(String[] args) {
        int arr[] = new int[100];
        // Random random=new Random();

        for (int i = 0; i < arr.length; i++) {
            arr[i]=(int)(Math.random()*100);
            System.out.println(arr[i]);
        }
    }
}