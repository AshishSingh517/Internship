package Java_Exercise_3;

import java.util.Scanner;

public class problem_11 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter a name");
        String name = sc.next();

        char[] ch = name.toCharArray();
        String reverse = "";
        int length = name.length();

        for (int i = length - 1; i >= 0; i--) {
            reverse = reverse + ch[i];

        }
        System.out.print("Reverse of String:" + reverse + "\n");
        if (name == reverse) {
            System.out.println(reverse + "is palindrome");
        } else {
            System.out.println(reverse + " is not a palindrome");
        }
    }
}