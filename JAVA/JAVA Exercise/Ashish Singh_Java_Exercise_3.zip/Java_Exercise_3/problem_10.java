package Java_Exercise_3;
import java.util.Scanner;
public class problem_10 {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int  count = 0;
        int[] rollno = {56, 78, 66, 34, 23, 67, 52, 87, 24, 83};
        System.out.println(" Array:");

        for (int i = 0; i < rollno.length; i++) {
            System.out.print(" " + rollno[i]);}
        System.out.println("\nEnter a search Element:");
            int n = sc.nextInt();
            for(int i=0;i<rollno.length;i++){
            if (rollno[i] == n) {
                count++;
            }
        }

            if(count>0){
                System.out.println("Element is found");
            }
            else{
                System.out.println("Elment is not found");
            }

    }
}