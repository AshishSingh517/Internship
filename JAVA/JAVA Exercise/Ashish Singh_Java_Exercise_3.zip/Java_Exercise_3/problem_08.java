package Java_Exercise_3;

public class problem_08 {
    public static void main(String[] args) {
        int[] marks = {10, 23, 24, 43, 22, 54, 12, 54, 67, 90};
        int sum = 0;
        for(int i=0;i<marks.length;i++){
            sum=sum+marks[i];
        }
        System.out.println("The Sum is:"+sum);
        System.out.println("The average marks of sum is:"+sum/marks.length);
    }

}
