package Java_Exercise_3;

public class problem_15 {
    int top=-1;
    int capacity;
    int[] stack;
    problem_15(){
    top=-1;
    capacity=20;
    stack=new int[capacity];
    }
    public boolean isempty(){
       return top==-1;
    }
    public boolean isfull(){
        return top==capacity-1;
    }
    public int push(int data){
        if(isfull()){
            System.out.println("Stack is full");
        }
        return stack[++top]=data;
    }
    public int pop(){
        if (isempty()){
            System.out.println("Stack is Empty");
        }
        return stack[top--];
    }
    public int peek(){
        return stack[top];

    }

    public static void main(String[] args) {
        problem_15 s=new problem_15();
        s.push(20);
        s.push(50);
        s.push(85);
        s.push(56);
        s.push(10);
        System.out.println(s.isempty());
        System.out.println(s.isfull());
        System.out.println("Capacity of stack is:"+s.capacity);
        System.out.println("The pop element is:"+s.pop());
        System.out.println("The top element is:"+s.peek());



    }
}
