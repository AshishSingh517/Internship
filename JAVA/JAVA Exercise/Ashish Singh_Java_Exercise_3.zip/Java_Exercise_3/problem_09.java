package Java_Exercise_3;

public class problem_09 {
    public static void main(String[] args) {
        int[] marks = {56, 78, 66, 34, 23, 67, 52, 87, 24, 83};
        for (int i = 0; i < marks.length; i++) {
            for (int j = i; j < marks.length; j++) {
                if (marks[i] > marks[j]) {
                    int temp = 0;
                    temp = marks[i];
                    marks[i] = marks[j];
                    marks[j] = temp;
                }
            }
        }
        System.out.println("Sorted of array in Ascending order:");
        for (int ms : marks) {
            System.out.print(" " + ms);
        }

        for (int i = 0; i < marks.length; i++) {
            for (int j = i; j < marks.length; j++) {
                if (marks[i] < marks[j]) {
                    int temp = 0;
                    temp = marks[i];
                    marks[i] = marks[j];
                    marks[j] = temp;
                }
            }
        }

        System.out.println("\nSorted of array in Descending order:");
        for (int as : marks) {
            System.out.print(" " + as);

        }
    }
}
