package Java_Exercise_3;

import java.util.Random;

public class problem_14 {
    public static void main(String[] args) {
        int arr[] = new int[100];
        // Random random=new Random();

        for (int i = 0; i < arr.length; i++) {
            arr[i]=(int)(Math.random()*100);

        }
        for(int i=0;i<arr.length;i++){
            for (int j=i+1;j<arr.length;j++){
                if (arr[i]==arr[j]){
                    arr[i]=-1;
                }
            }
        }
        System.out.println("Removed array is:");
        for(int i=0;i<arr.length;i++){
            if (arr[i]!=-1){
                System.out.print(" "+arr[i]);
            }
        }
    }
}