package Java_Exercise_3;

import java.util.Arrays;

public class problem_12_01 {
    public static void main(String[] args) {
        int[] a1={2,3,4,5,6,7};
        int[] a2={2,4,3,5,6,7};

Arrays.sort(a1);
Arrays.sort(a2);

        if(Arrays.equals(a1,a2)){
            System.out.println("Arrays are equal");
        }
        else{
            System.out.println("Arrays are not equal");
        }
    }
}
