package Java_Exercise_3;

import java.util.Queue;

public class problem_16 {
    int arr[];
    int size = 10;
    int rear = -1;

    problem_16(int n) {
        arr = new int[size];

    }

    public boolean isEmpty() {
        return rear == -1;
    }

    public void add(int data) {
        if (rear == size - 1) {
            System.out.println("Queue is full");
        }
        rear++;
        arr[rear] = data;

    }

    public int remove() {
        if (isEmpty()) {
            System.out.println("Queue is Empty");
            return -1;
        }

        int front = arr[0];
        for (int i = 0; i < rear; i++) {
            arr[i] = arr[i + 1];
        }
        return front;
    }

    public int peek() {
        if (isEmpty()) {
            return -1;
        }
return arr[0];

    }
    public static void main(String[] args) {
        problem_16 q=new problem_16(10);
        q.add(45);
        q.add(25);
        q.add(56);
        System.out.println("The capacity of Queue is:"+q.size);
        System.out.println("The removed element is:"+q.remove());
        System.out.println("The top element is: "+q.peek());

    }
    }
